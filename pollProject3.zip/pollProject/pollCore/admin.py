from django.contrib import admin

from pollCore.models import Poll

admin.site.register(Poll)
