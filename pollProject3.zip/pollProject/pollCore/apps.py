from django.apps import AppConfig


class PollcoreConfig(AppConfig):
    name = 'pollCore'
